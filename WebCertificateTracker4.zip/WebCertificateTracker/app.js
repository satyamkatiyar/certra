angular.module('app', ['ngAnimate', 'ngTouch', 'ui.grid'])
  .controller('MainCtrl', MainCtrl)
  //.filter('mapGender', mapGender);

MainCtrl.$inject = ['$http', 'uiGridConstants'];

function MainCtrl($http, uiGridConstants) {
  var vm = this,
    today = new Date(),
    nextWeek = new Date();

  nextWeek.setDate(nextWeek.getDate() + 7);

  vm.highlightFilteredHeader = function( row, rowRenderIndex, col, colRenderIndex ) {
    if( col.filters[0].term ){
      return 'header-filtered';
    } else {
      return '';
    }
  };

  vm.gridOptions = {
    enableFiltering: true,
    onRegisterApi: function(gridApi){
      vm.gridApi = gridApi;
    },
    columnDefs: [
      // default
      { field: 'CertificateName', headerCellClass: vm.highlightFilteredHeader, width:200 },
      { field: 'CertificateSerialNumber', headerCellClass: vm.highlightFilteredHeader, width:230  },
      { field: 'CertificateProvider', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'ExpiryDate', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'DaysToExpire', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'DistributionList', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'CertificateType', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'CostCenter', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'LatestWOnumber', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'TOM', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'Application', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'Environment', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'IsAcknowledged', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'AcknowledgedBy', headerCellClass: vm.highlightFilteredHeade, width:200  },
      { field: 'AcknowledgedOn', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'ThumbPrint', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'CreatedDate', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'CreatedBy', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'UpdatedDate', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'UpdatedBy', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'MachineName', headerCellClass: vm.highlightFilteredHeader, width:200  },
      { field: 'MachineIP', headerCellClass: vm.highlightFilteredHeader, width:200  }
      // pre-populated search field
      // { field: 'gender', filter: {
      //     term: '1',
      //     type: uiGridConstants.filter.SELECT,
      //     selectOptions: [ { value: '1', label: 'male' }, { value: '2', label: 'female' }, { value: '3', label: 'unknown'}, { value: '4', label: 'not stated' }, { value: '5', label: 'a really long value that extends things' } ]
      //   },
      //   cellFilter: 'mapGender', headerCellClass: vm.highlightFilteredHeader },
      // // no filter input
      // { field: 'company', enableFiltering: false, filter: {
      //   noTerm: true,
      //   condition: function(searchTerm, cellValue) {
      //     return cellValue.match(/a/);
      //   }
      // }},
      // specifies one of the built-in conditions
      // and a placeholder for the input
      // {
      //   field: 'email',
      //   filter: {
      //     condition: uiGridConstants.filter.ENDS_WITH,
      //     placeholder: 'ends with'
      //   }, headerCellClass: vm.highlightFilteredHeader
      // },
      // // custom condition function
      // {
      //   field: 'phone',
      //   filter: {
      //     condition: function(searchTerm, cellValue) {
      //       var strippedValue = (cellValue + '').replace(/[^\d]/g, '');
      //       return strippedValue.indexOf(searchTerm) >= 0;
      //     }
      //   }, headerCellClass: vm.highlightFilteredHeader
      // },
      // multiple filters
      // { field: 'age', filters: [
      //   {
      //     condition: uiGridConstants.filter.GREATER_THAN,
      //     placeholder: 'greater than'
      //   },
      //   {
      //     condition: uiGridConstants.filter.LESS_THAN,
      //     placeholder: 'less than'
      //   }
      // ], headerCellClass: vm.highlightFilteredHeader},
      // // date filter
      // { field: 'mixedDate', cellFilter: 'date', width: '15%', filter: {
      //     condition: uiGridConstants.filter.LESS_THAN,
      //     placeholder: 'less than',
      //     term: nextWeek
      //   }, headerCellClass: vm.highlightFilteredHeader
      // },
      // {
      //   field: 'mixedDate',
      //   displayName: 'Long Date',
      //   cellFilter: 'date:"longDate"',
      //   filterCellFiltered: true,
      //   width: '15%'
      // }
    ]
  };
  vm.totalCount = 0;
  $http.get('http://localhost/CertificateTracker/api/CertificateTracker/GetCertificateDetails')
    .then(function(response) {
      vm.gridOptions.data = response.data.results;
      vm.totalCount = response.data.results.length;
      //vm.gridOptions.data[0].age = -5;

      // response.data.forEach( function addDates( row, index ){
      //   row.mixedDate = new Date();
      //   row.mixedDate.setDate(today.getDate() + ( index % 14 ) );
      //   row.gender = row.gender === 'male' ? '1' : '2';
      // });
    });

  vm.toggleFiltering = function(){
    vm.gridOptions.enableFiltering = !vm.gridOptions.enableFiltering;
    vm.gridApi.core.notifyDataChange( uiGridConstants.dataChange.COLUMN );
  };
  vm.Filter = function(filtercategory, filterparam){
    console.log(filterparam);
    var url = 'http://localhost/CertificateTracker/api/CertificateTracker/GetCertificateDetails';
    var params = '';
    if(filtercategory && filterparam)
      params = '?'+ filtercategory + '=' + filterparam;
    url = url + params;
    $http.get(url)
    .then(function(response) {
      vm.gridOptions.data = response.data.results;
      vm.totalCount = response.data.results.length;
      //vm.gridOptions.data[0].age = -5;

      // response.data.forEach( function addDates( row, index ){
      //   row.mixedDate = new Date();
      //   row.mixedDate.setDate(today.getDate() + ( index % 14 ) );
      //   row.gender = row.gender === 'male' ? '1' : '2';
      // });
    });
  };
  

}

// function mapGender() {
//   var genderHash = {
//     1: 'male',
//     2: 'female'
//   };

//   return function(input) {
//     if (!input){
//       return '';
//     } else {
//       return genderHash[input];
//     }
//   };
// }
